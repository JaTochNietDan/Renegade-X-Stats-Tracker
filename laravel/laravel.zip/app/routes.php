<?php

Route::get('/', array('uses' => 'MainController@index', 'as' => 'home'));
Route::get('/player/{id}', array('uses' => 'PlayerController@show', 'as' => 'player'));
Route::get('/search', array('uses' => 'PlayerController@search', 'as' => 'search'));
Route::get('/losers', array('uses' => 'MainController@losers', 'as' => 'losers'));