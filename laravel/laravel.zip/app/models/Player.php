<?php

class Player extends Eloquent
{
    protected $table = 'players';
    
    public static function getKDR($total = 10)
    {
        return Player::select(DB::raw('*, kills / deaths AS kdr'))
                ->orderBy('kdr', 'desc')
                ->take($total)
                ->get();
    }
}
