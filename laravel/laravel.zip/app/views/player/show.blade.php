@extends('layout')

@section('content')
    <div class="row">
        <div class="col-lg-4">
            <div class="panel panel-default">
                <div class="panel-heading">Stats for {{ $p->name }}</div>
                <table class="table table-bordered table-striped">
                    <tbody>
                        <tr>
                            <th>Name</th>
                            <td><a href="{{ route('player', $p->steamid) }}">{{ $p->name }}</a> (<a href="http://steamcommunity.com/profiles/{{ $p->steamid }}" target="_blank">Steam Profile</a>)</td>
                        </tr>
                        <tr>
                            <th>Kills</th>
                            <td>{{ number_format($p->kills) }}</td>
                        </tr>
                        <tr>
                            <th>Deaths</th>
                            <td>{{ number_format($p->deaths) }}</td>
                        </tr>
                        <tr>
                            <th>Headshots</th>
                            <td>{{ number_format($p->headshots) }} ({{ number_format($p->kills > 0 ? ($p->headshots / $p->kills) * 100 : $p->headshots, 2) }}% of kills)</td>
                        </tr>
                        <tr>
                            <th>Longest Killstreak</th>
                            <td>{{ $p->killstreak }}</td>
                        </tr>
                        <tr>
                            <th>KDR</th>
                            <td>{{ number_format($p->deaths > 0 ? $p->kills / $p->deaths : $p->kills, 2) }}</td>
                        </tr>
                        <tr>
                            <th>Buildings Ruined</th>
                            <td>{{ number_format($p->buildings) }}</td>
                        </tr>
                        <tr>
                            <th>Vehicles Wrecked</th>
                            <td>{{ number_format($p->destroyed) }}</td>
                        </tr>
                        <tr>
                            <th>Longest Deathstreak</th>
                            <td>{{ $p->deathstreak }}</td>
                        </tr>
                        <tr>
                            <th>Roadkill</th>
                            <td>{{ number_format($p->runover) }}</td>
                        </tr>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
@stop