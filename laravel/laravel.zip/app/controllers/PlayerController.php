<?php

class PlayerController extends Controller
{
    function show($id)
    {
        $p = Player::where('steamid', '=', $id)->take(1)->get()->first();
        
        if(!$p)
            return Redirect::to(route('home'))->withErrors(array('Player with that ID not found!'));
        
        return View::make('player.show', array('p' => $p));
    }
    
    function search()
    {
        $players = Player::where('name', 'LIKE', '%'.Input::get('name').'%')->take(20)->get();
        
        return View::make('player.search', array('players' => $players));
    }
}
